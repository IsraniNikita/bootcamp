# yourname-hello

A simple Python module that greets the world (or a person you choose).

[![TestPyPI](https://img.shields.io/badge/TestPyPI-Package-blue)](https://test.pypi.org/project/NikitaIsrani-hello/)


## Installation

```bash
pip install -i https://test.pypi.org/simple/ NikitaIsrani-hello
