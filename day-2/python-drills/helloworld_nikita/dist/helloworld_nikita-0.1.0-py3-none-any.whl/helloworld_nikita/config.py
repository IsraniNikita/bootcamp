import os
import yaml
import logging

logger = logging.getLogger(__name__)

def load_config() -> dict:
    paths = [os.getcwd()]
    config_env = os.getenv("CONFIG_PATH")
    if config_env:
        paths.extend(config_env.split(":"))
    paths.append(os.path.join(os.path.dirname(__file__), "_default_config.yaml"))

    for path in paths:
        try:
            config_file = os.path.join(path, "_config.yaml")
            if os.path.exists(config_file):
                with open(config_file, "r") as f:
                    logger.debug(f"Loading config from {config_file}")
                    return yaml.safe_load(f)
        except Exception as e:
            logger.warning(f"Error loading config from {path}: {e}")

    logger.warning("No config found, using default")
    return {"num_times": 1}
