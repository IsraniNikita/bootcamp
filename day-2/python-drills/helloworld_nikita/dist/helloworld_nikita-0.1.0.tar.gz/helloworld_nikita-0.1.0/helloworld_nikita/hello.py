from .config import load_config

def say_hello(name: str) -> str:
    config = load_config()
    times = config.get("num_times", 1)
    return "\n".join([f"Hello, {name}!" for _ in range(times)])
